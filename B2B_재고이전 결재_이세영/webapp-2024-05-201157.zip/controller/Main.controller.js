sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
],
function (Controller, MessageToast, Filter, FilterOperator) {
    "use strict";

    return Controller.extend("sync.e17.inventory4.controller.Main", {
        onInit: function () {
            this.getPlantDescriptions();
        },

        onApprove: function () {
            var oTable = this.byId("inventoryTable");
            var aSelectedIndices = oTable.getSelectedIndices();

            if (aSelectedIndices.length === 0) {
                MessageToast.show("항목을 선택하세요.");
                return;
            }

            var oModel = this.getView().getModel();
            var aPromises = [];

            aSelectedIndices.forEach(function (iIndex) {
                var oContext = oTable.getContextByIndex(iIndex);
                var sPath = oContext.getPath();

                var oData = oContext.getObject();
                oData.STATUS = 'R'; // Update STATUS field

                aPromises.push(new Promise(function (resolve, reject) {
                    oModel.update(sPath, oData, {
                        success: function() {
                            resolve();
                            MessageToast.show("승인 완료");
                        },
                        error: function() {
                            reject();
                            MessageToast.show("승인 실패");
                        }
                    });
                }));
            });

            Promise.all(aPromises)
                .then(function () {
                    this.getInventoryData();
                }.bind(this))
                .catch(function () {
                    // 에러가 발생한 경우 이미 Message Toast가 표시되었으므로 추가 조치가 필요하지 않습니다.
                });
        },

        onRefresh: function () {
            this.getInventoryData();
            MessageToast.show("새로고침 완료");
        },

        getPlantDescriptions: function () {
            // 예시 데이터로 대체 (Plantfr에 따른 설명을 가져와야 함)
            var oPlantDescriptions = {
                "10000": "CDC",
                "10001": "RDC"
            };
            var oPlantCombo = this.byId("plantComboBox");
            var aItems = oPlantCombo.getItems();

            aItems.forEach(function (oItem) {
                var sKey = oItem.getKey();
                var sDescription = oPlantDescriptions[sKey];
                if (sDescription) {
                    oItem.setText(sKey + " : " + sDescription);
                }
            });
        },

        getInventoryData: function () {
            var oTable = this.byId("inventoryTable");
            var oModel = this.getView().getModel(); // Assuming the model is already set
            var sSelectedPlant = this.getView().getModel("plantModel").getProperty("/selectedPlant");

            var aFilters = [];
            if (sSelectedPlant) {
                aFilters.push(new Filter("Plantfr", FilterOperator.EQ, sSelectedPlant));
            }

            oTable.getBinding("rows").filter(aFilters);
        },

        onPlantChange: function (oEvent) {
            var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
            this.getView().getModel("plantModel").setProperty("/selectedPlant", sSelectedKey);

            this.getInventoryData();
        },
        onDelete: function (oEvent) {
            var oTable = this.byId("inventoryTable");
            var oSelectedItem = oTable.getSelectedItem();
        
            if (!oSelectedItem) {
                MessageToast.show("삭제할 항목을 선택하세요.");
                return;
            }
        
            var oContext = oSelectedItem.getBindingContext();
            var sPath = oContext.getPath();
            var oModel = this.getView().getModel();
        
            var oData = oContext.getObject();
            oData.STATUS = 'R'; // Update STATUS field
        
            oModel.update(sPath, oData, {
                success: function () {
                    MessageToast.show("선택한 라인의 STATUS를 'R'로 업데이트했습니다.");
                },
                error: function () {
                    MessageToast.show("라인을 업데이트하는 동안 오류가 발생했습니다.");
                }
            });
        }
        
    });
});
