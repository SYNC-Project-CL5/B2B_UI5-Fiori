sap.ui.define([
	"synce17/inventory4/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
