/* global QUnit */

sap.ui.require(["sync/e17/inventory4/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
