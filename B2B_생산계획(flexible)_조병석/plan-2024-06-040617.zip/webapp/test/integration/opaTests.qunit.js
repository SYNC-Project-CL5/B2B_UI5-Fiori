/* global QUnit */

sap.ui.require(["sync/ea/plan/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
