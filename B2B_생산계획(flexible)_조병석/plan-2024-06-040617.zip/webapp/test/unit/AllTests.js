sap.ui.define([
	"syncea/plan/test/unit/controller/Master.controller"
], function () {
	"use strict";
});
